import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IProduct } from 'src/app/models/product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private _productUrl : string= 'assets/products.json';

  constructor(private http: HttpClient) { }


    getProducts():Observable<IProduct[]> {
      const header = new HttpHeaders({'content-type': 'application/json'})
      return this.http.get<IProduct[]>(this._productUrl ,{headers: header},);
     
    }
}
